import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory-fns-BRTkMRMG.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_inventory_default = "create table if not exists categories (\n  id serial primary key,\n  name text not null unique,\n  sort_order integer not null default 0,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists products (\n  id serial primary key,\n  category_id integer not null references categories(id),\n  sku text not null,\n  packing_qty integer not null,\n  packing_unit text not null default '个',\n  sort_order integer not null default 0,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists variants (\n  id serial primary key,\n  product_id integer not null references products(id) on delete cascade,\n  color text not null,\n  remaining_cartons integer not null default 0,\n  remaining_sets integer not null default 0,\n  sort_order integer not null default 0,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate unique index if not exists variants_product_color_idx\n  on variants (product_id, color);\n\ncreate index if not exists products_category_id_idx on products (category_id);\ncreate index if not exists variants_product_id_idx on variants (product_id);\n\ncreate table if not exists stock_movements (\n  id serial primary key,\n  variant_id integer not null references variants(id) on delete cascade,\n  movement_date date not null,\n  kind text not null,\n  cartons integer not null default 0,\n  sets integer not null default 0,\n  note text,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists stock_movements_variant_date_idx\n  on stock_movements (variant_id, movement_date);\n\ncreate table if not exists app_settings (\n  key text primary key,\n  value text not null\n);\n\ninsert into app_settings (key, value)\nvalues ('warehouse_name', '芳村仓')\non conflict (key) do nothing;\n\ninsert into categories (id, name, sort_order)\nvalues (1, '纸罐&铁罐', 1)\non conflict (name) do nothing;\n\n-- Reset sequences after explicit ids\nselect setval('categories_id_seq', (select coalesce(max(id), 1) from categories));\n\ninsert into products (id, category_id, sku, packing_qty, packing_unit, sort_order)\nvalues\n  (1, 1, 'H1405-83雅礼花罐', 72, '个', 1),\n  (2, 1, 'H1506-73慢品（高）', 150, '个', 2),\n  (3, 1, 'H1506-73B慢品（矮）', 200, '个', 3),\n  (4, 1, 'H1506-83慢品', 70, '个', 4)\non conflict (id) do nothing;\n\nselect setval('products_id_seq', (select coalesce(max(id), 1) from products));\n\ninsert into variants (id, product_id, color, remaining_cartons, remaining_sets, sort_order)\nvalues\n  (1, 1, '黄色', 7, 25, 1),\n  (2, 1, '红色', 1, 121, 2),\n  (3, 2, '橙色', 0, 0, 1),\n  (4, 2, '绿色', 5, 52, 2),\n  (5, 3, '橙色', 7, 30, 1),\n  (6, 3, '红色', 2, 67, 2),\n  (7, 3, '绿色', 0, 61, 3),\n  (8, 4, '红色', 19, 44, 1),\n  (9, 4, '橙色', 11, 10, 2),\n  (10, 4, '绿色', 0, 0, 3)\non conflict (id) do nothing;\n\nselect setval('variants_id_seq', (select coalesce(max(id), 1) from variants));\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_inventory.sql": _0002_inventory_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function isUniqueViolation(err) {
	const e = err;
	return e.code === "23505" || /unique|duplicate/i.test(e.message ?? "");
}
function asInt(value, fallback = 0) {
	const n = Number(value);
	return Number.isFinite(n) ? n : fallback;
}
function subtractStock(cartons, sets, outCartons, outSets, packingQty) {
	let nextCartons = cartons - outCartons;
	let nextSets = sets - outSets;
	const pack = packingQty > 0 ? packingQty : 0;
	while (nextSets < 0 && pack > 0 && nextCartons > 0) {
		nextCartons -= 1;
		nextSets += pack;
	}
	if (nextCartons < 0 || nextSets < 0) throw new Error("库存不足，无法出库");
	return {
		cartons: nextCartons,
		sets: nextSets
	};
}
async function loadInventory(date, query) {
	const sql = await getSql();
	const pattern = `%${query.trim()}%`;
	const [settingRows, categoryRows, productRows, variantRows, movementRows] = await Promise.all([
		sql`select value from app_settings where key = ${"warehouse_name"}`,
		sql`select id, name, sort_order from categories order by sort_order, id`,
		sql`
        select id, category_id, sku, packing_qty, packing_unit, sort_order
        from products
        order by sort_order, id
      `,
		sql`
        select v.id, v.product_id, v.color, v.remaining_cartons, v.remaining_sets, v.sort_order
        from variants v
        join products p on p.id = v.product_id
        where p.sku ilike ${pattern} or v.color ilike ${pattern}
        order by v.sort_order, v.id
      `,
		sql`
        select
          variant_id,
          coalesce(sum(case when kind = 'in' then cartons else 0 end), 0) as in_cartons,
          coalesce(sum(case when kind = 'in' then sets else 0 end), 0) as in_sets,
          coalesce(sum(case when kind = 'out' then cartons else 0 end), 0) as out_cartons,
          coalesce(sum(case when kind = 'out' then sets else 0 end), 0) as out_sets
        from stock_movements
        where movement_date = ${date}
        group by variant_id
      `
	]);
	const movementMap = /* @__PURE__ */ new Map();
	for (const row of movementRows) movementMap.set(row.variant_id, row);
	const variantsByProduct = /* @__PURE__ */ new Map();
	for (const row of variantRows) {
		const list = variantsByProduct.get(row.product_id) ?? [];
		list.push(row);
		variantsByProduct.set(row.product_id, list);
	}
	const hasQuery = query.trim().length > 0;
	const categories = [];
	let productCount = 0;
	let variantCount = 0;
	let outOfStock = 0;
	let todayInLines = 0;
	let todayOutLines = 0;
	for (const category of categoryRows) {
		const products = [];
		for (const product of productRows) {
			if (product.category_id !== category.id) continue;
			const vars = variantsByProduct.get(product.id) ?? [];
			if (hasQuery && vars.length === 0) continue;
			productCount += 1;
			products.push({
				id: product.id,
				categoryId: product.category_id,
				sku: product.sku,
				packingQty: product.packing_qty,
				packingUnit: product.packing_unit,
				sortOrder: product.sort_order,
				variants: vars.map((v) => {
					const m = movementMap.get(v.id);
					const inCartons = asInt(m?.in_cartons ?? 0);
					const inSets = asInt(m?.in_sets ?? 0);
					const outCartons = asInt(m?.out_cartons ?? 0);
					const outSets = asInt(m?.out_sets ?? 0);
					variantCount += 1;
					if (v.remaining_cartons === 0 && v.remaining_sets === 0) outOfStock += 1;
					if (inCartons !== 0 || inSets !== 0) todayInLines += 1;
					if (outCartons !== 0 || outSets !== 0) todayOutLines += 1;
					return {
						id: v.id,
						productId: v.product_id,
						color: v.color,
						remainingCartons: v.remaining_cartons,
						remainingSets: v.remaining_sets,
						inCartons,
						inSets,
						outCartons,
						outSets,
						sortOrder: v.sort_order
					};
				})
			});
		}
		if (hasQuery && products.length === 0) continue;
		categories.push({
			id: category.id,
			name: category.name,
			sortOrder: category.sort_order,
			products
		});
	}
	return {
		warehouseName: settingRows[0]?.value ?? "芳村仓",
		date,
		categories,
		stats: {
			productCount,
			variantCount,
			outOfStock,
			todayInLines,
			todayOutLines
		}
	};
}
var dateInput = object({
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	q: string().optional()
});
var listInventory_createServerFn_handler = createServerRpc({
	id: "b4d57d43658cf0656ea7f7a2c3a742ce03669863383ec2731e7d801e29c2eb53",
	name: "listInventory",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => listInventory.__executeServer(opts));
var listInventory = createServerFn({ method: "POST" }).validator((input) => dateInput.parse(input)).handler(listInventory_createServerFn_handler, async ({ data }) => loadInventory(data.date, data.q ?? ""));
var listCategories_createServerFn_handler = createServerRpc({
	id: "c583db61e6832c9f2ab9234aa3564e88eb66fbaf0b1245e29699488f11a410b8",
	name: "listCategories",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => listCategories.__executeServer(opts));
var listCategories = createServerFn({ method: "GET" }).handler(listCategories_createServerFn_handler, async () => {
	return (await (await getSql())`
    select id, name, sort_order from categories order by sort_order, id
  `).map((row) => ({
		id: row.id,
		name: row.name
	}));
});
var createCategoryInput = object({ name: string().trim().min(1).max(40) });
var createCategory_createServerFn_handler = createServerRpc({
	id: "de4a1711697083440ea3c717fe4a09096eda99fd6efb65eb1e931b1364262a9c",
	name: "createCategory",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => createCategory.__executeServer(opts));
var createCategory = createServerFn({ method: "POST" }).validator((input) => createCategoryInput.parse(input)).handler(createCategory_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const sortOrder = asInt((await sql`select max(sort_order) as max from categories`)[0]?.max ?? 0) + 1;
	try {
		const row = (await sql`
        insert into categories (name, sort_order)
        values (${data.name}, ${sortOrder})
        returning id, name, sort_order
      `)[0];
		if (!row) throw new Error("新建分类失败");
		return {
			id: row.id,
			name: row.name
		};
	} catch (err) {
		if (isUniqueViolation(err)) throw new Error("分类已存在");
		throw err;
	}
});
var deleteCategoryInput = object({ id: number().int() });
var deleteCategory_createServerFn_handler = createServerRpc({
	id: "0451513c68df54a1613deacffce8f664711fd087c4afc67296b054cc5e1cf617",
	name: "deleteCategory",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => deleteCategory.__executeServer(opts));
var deleteCategory = createServerFn({ method: "POST" }).validator((input) => deleteCategoryInput.parse(input)).handler(deleteCategory_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	if (asInt((await sql`
      select count(*)::int as count from products where category_id = ${data.id}
    `)[0]?.count ?? 0) > 0) throw new Error("该分类下仍有货品，无法删除");
	await sql`delete from categories where id = ${data.id}`;
	return { ok: true };
});
var createProductInput = object({
	categoryId: number().int(),
	sku: string().trim().min(1).max(80),
	packingQty: number().int().positive(),
	packingUnit: string().trim().min(1).max(8),
	color: string().trim().min(1).max(20),
	remainingCartons: number().int().min(0),
	remainingSets: number().int().min(0)
});
var createProduct_createServerFn_handler = createServerRpc({
	id: "f435bfac7f7da5ba1ace11b4ffa3dc58561c24ae456aa614eb6149b17b157a8a",
	name: "createProduct",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => createProduct.__executeServer(opts));
var createProduct = createServerFn({ method: "POST" }).validator((input) => createProductInput.parse(input)).handler(createProduct_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const sortOrder = asInt((await sql`
      select max(sort_order) as max from products where category_id = ${data.categoryId}
    `)[0]?.max ?? 0) + 1;
	const productId = (await sql`
      insert into products (category_id, sku, packing_qty, packing_unit, sort_order)
      values (${data.categoryId}, ${data.sku}, ${data.packingQty}, ${data.packingUnit}, ${sortOrder})
      returning id
    `)[0]?.id;
	if (!productId) throw new Error("新增货品失败");
	await sql`
      insert into variants (product_id, color, remaining_cartons, remaining_sets, sort_order)
      values (${productId}, ${data.color}, ${data.remainingCartons}, ${data.remainingSets}, 1)
    `;
	return { id: productId };
});
var updateProductInput = object({
	id: number().int(),
	categoryId: number().int(),
	sku: string().trim().min(1).max(80),
	packingQty: number().int().positive(),
	packingUnit: string().trim().min(1).max(8)
});
var updateProduct_createServerFn_handler = createServerRpc({
	id: "f171e30993b05043d175c240acbe9f68ea2882aa5d4049081b9f5c8cfc811f30",
	name: "updateProduct",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => updateProduct.__executeServer(opts));
var updateProduct = createServerFn({ method: "POST" }).validator((input) => updateProductInput.parse(input)).handler(updateProduct_createServerFn_handler, async ({ data }) => {
	await (await getSql())`
      update products
      set category_id = ${data.categoryId},
          sku = ${data.sku},
          packing_qty = ${data.packingQty},
          packing_unit = ${data.packingUnit},
          updated_at = now()
      where id = ${data.id}
    `;
	return { ok: true };
});
var deleteProductInput = object({ id: number().int() });
var deleteProduct_createServerFn_handler = createServerRpc({
	id: "f4713014b6377bbc561759ec31a67463fed1eaf81b8f8d99ad6f32aaacd4e0ff",
	name: "deleteProduct",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => deleteProduct.__executeServer(opts));
var deleteProduct = createServerFn({ method: "POST" }).validator((input) => deleteProductInput.parse(input)).handler(deleteProduct_createServerFn_handler, async ({ data }) => {
	await (await getSql())`delete from products where id = ${data.id}`;
	return { ok: true };
});
var createVariantInput = object({
	productId: number().int(),
	color: string().trim().min(1).max(20),
	remainingCartons: number().int().min(0),
	remainingSets: number().int().min(0)
});
var createVariant_createServerFn_handler = createServerRpc({
	id: "8dcbe2fa136c3f389a85d0bec99c96664be889213da9a98293c4fbee3a6e84b3",
	name: "createVariant",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => createVariant.__executeServer(opts));
var createVariant = createServerFn({ method: "POST" }).validator((input) => createVariantInput.parse(input)).handler(createVariant_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const sortOrder = asInt((await sql`
      select max(sort_order) as max from variants where product_id = ${data.productId}
    `)[0]?.max ?? 0) + 1;
	try {
		return { id: (await sql`
        insert into variants (product_id, color, remaining_cartons, remaining_sets, sort_order)
        values (${data.productId}, ${data.color}, ${data.remainingCartons}, ${data.remainingSets}, ${sortOrder})
        returning id
      `)[0]?.id };
	} catch (err) {
		if (isUniqueViolation(err)) throw new Error("该货号下已有此颜色");
		throw err;
	}
});
var updateVariantInput = object({
	id: number().int(),
	color: string().trim().min(1).max(20)
});
var updateVariant_createServerFn_handler = createServerRpc({
	id: "a3e38e0f55a1c3d0d01d152716fd6372ba525cf610d269930958765b3d755a55",
	name: "updateVariant",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => updateVariant.__executeServer(opts));
var updateVariant = createServerFn({ method: "POST" }).validator((input) => updateVariantInput.parse(input)).handler(updateVariant_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	try {
		await sql`
        update variants
        set color = ${data.color}, updated_at = now()
        where id = ${data.id}
      `;
		return { ok: true };
	} catch (err) {
		if (isUniqueViolation(err)) throw new Error("该货号下已有此颜色");
		throw err;
	}
});
var deleteVariantInput = object({ id: number().int() });
var deleteVariant_createServerFn_handler = createServerRpc({
	id: "989c7d4c1d5a03e7641125e6cb4c8709b645c4a53a9a3ac5b8750c82ad52791c",
	name: "deleteVariant",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => deleteVariant.__executeServer(opts));
var deleteVariant = createServerFn({ method: "POST" }).validator((input) => deleteVariantInput.parse(input)).handler(deleteVariant_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const row = (await sql`
      select v.product_id, (
        select count(*)::int from variants v2 where v2.product_id = v.product_id
      ) as count
      from variants v
      where v.id = ${data.id}
    `)[0];
	if (!row) throw new Error("颜色不存在");
	if (asInt(row.count) <= 1) throw new Error("至少保留一种颜色，如需删除请直接删除货号");
	await sql`delete from variants where id = ${data.id}`;
	return { ok: true };
});
var recordMovementInput = object({
	variantId: number().int(),
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	kind: _enum([
		"in",
		"out",
		"adjust"
	]),
	cartons: number().int().min(0),
	sets: number().int().min(0),
	note: string().trim().max(120).optional()
});
var recordMovement_createServerFn_handler = createServerRpc({
	id: "1b75eb6ba4817beb640e55e278f52125c3dfdc5bc08770d584a1cd843f9e2748",
	name: "recordMovement",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => recordMovement.__executeServer(opts));
var recordMovement = createServerFn({ method: "POST" }).validator((input) => recordMovementInput.parse(input)).handler(recordMovement_createServerFn_handler, async ({ data }) => {
	if (data.kind !== "adjust" && data.cartons === 0 && data.sets === 0) throw new Error("请填写件数或套数");
	const sql = await getSql();
	const variant = (await sql`
      select v.id, v.product_id, v.color, v.remaining_cartons, v.remaining_sets, v.sort_order,
             p.packing_qty
      from variants v
      join products p on p.id = v.product_id
      where v.id = ${data.variantId}
    `)[0];
	if (!variant) throw new Error("货品不存在");
	let nextCartons = variant.remaining_cartons;
	let nextSets = variant.remaining_sets;
	if (data.kind === "in") {
		nextCartons += data.cartons;
		nextSets += data.sets;
	} else if (data.kind === "out") {
		const next = subtractStock(variant.remaining_cartons, variant.remaining_sets, data.cartons, data.sets, variant.packing_qty);
		nextCartons = next.cartons;
		nextSets = next.sets;
	} else {
		nextCartons = data.cartons;
		nextSets = data.sets;
	}
	await sql`
      update variants
      set remaining_cartons = ${nextCartons},
          remaining_sets = ${nextSets},
          updated_at = now()
      where id = ${data.variantId}
    `;
	await sql`
      insert into stock_movements (variant_id, movement_date, kind, cartons, sets, note)
      values (
        ${data.variantId},
        ${data.date},
        ${data.kind},
        ${data.cartons},
        ${data.sets},
        ${data.note || null}
      )
    `;
	return {
		remainingCartons: nextCartons,
		remainingSets: nextSets
	};
});
var listMovementsInput = object({ variantId: number().int() });
var listMovements_createServerFn_handler = createServerRpc({
	id: "05710ed64c775337bb648213fa06a3d921ed64d72896e4174bc506ead86f0b4c",
	name: "listMovements",
	filename: "src/lib/inventory-fns.ts"
}, (opts) => listMovements.__executeServer(opts));
var listMovements = createServerFn({ method: "POST" }).validator((input) => listMovementsInput.parse(input)).handler(listMovements_createServerFn_handler, async ({ data }) => {
	return (await (await getSql())`
      select
        m.id,
        m.variant_id,
        p.sku,
        v.color,
        m.movement_date,
        m.kind,
        m.cartons,
        m.sets,
        m.note,
        m.created_at
      from stock_movements m
      join variants v on v.id = m.variant_id
      join products p on p.id = v.product_id
      where m.variant_id = ${data.variantId}
      order by m.movement_date desc, m.id desc
      limit 100
    `).map((row) => ({
		id: row.id,
		variantId: row.variant_id,
		sku: row.sku,
		color: row.color,
		movementDate: row.movement_date,
		kind: row.kind,
		cartons: row.cartons,
		sets: row.sets,
		note: row.note,
		createdAt: row.created_at
	}));
});
//#endregion
export { createCategory_createServerFn_handler, createProduct_createServerFn_handler, createVariant_createServerFn_handler, deleteCategory_createServerFn_handler, deleteProduct_createServerFn_handler, deleteVariant_createServerFn_handler, listCategories_createServerFn_handler, listInventory_createServerFn_handler, listMovements_createServerFn_handler, recordMovement_createServerFn_handler, updateProduct_createServerFn_handler, updateVariant_createServerFn_handler };
