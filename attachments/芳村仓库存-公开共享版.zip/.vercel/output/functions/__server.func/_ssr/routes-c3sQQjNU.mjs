import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as Slot, N as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, i as Description2, l as Dialog$1, m as DialogPortal$1, n as Cancel, o as Portal2, p as DialogOverlay$1, r as Content2, s as Root2, t as Action, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as _enum } from "../_libs/zod.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as Plus, c as ChevronDown, i as Search, l as Check, n as Warehouse, o as FolderTree, s as Ellipsis, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Separator2, i as Root2$1, n as Item2, o as Trigger, r as Portal2$1, t as Content2$1 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as SelectItemIndicator, c as SelectTrigger$1, i as SelectItem$1, l as SelectValue$1, n as SelectContent$1, o as SelectItemText, r as SelectIcon, s as SelectPortal, t as Select$1, u as SelectViewport } from "../_libs/@radix-ui/react-select+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-c3sQQjNU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,opacity,transform,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-ring/40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			destructive: "bg-primary text-primary-foreground hover:bg-primary/90",
			outline: "border border-border bg-card text-foreground hover:bg-accent",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent",
			ghost: "hover:bg-accent text-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 rounded-sm px-3 text-xs",
			lg: "h-11 px-5",
			icon: "size-10",
			"icon-sm": "size-8"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("h-10 w-full min-w-0 rounded-md border border-input bg-card px-3 text-sm text-foreground shadow-none outline-none transition-[border-color,box-shadow] duration-150", "placeholder:text-muted-foreground", "focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30", "disabled:cursor-not-allowed disabled:opacity-50", "file:border-0 file:bg-transparent file:text-sm file:font-medium", className),
		...props
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-muted", className),
		...props
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
		className: cn("fixed inset-0 z-50 bg-foreground/30 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function AlertDialogContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-popover p-5 text-popover-foreground shadow-ledger", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props
	})] });
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
		className: cn("font-display text-lg font-semibold", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
		className: cn(buttonVariants(), className),
		...props
	});
}
function AlertDialogCancel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
		className: cn(buttonVariants({ variant: "outline" }), className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-foreground/30 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-popover p-5 text-popover-foreground shadow-ledger", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-sm p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "关闭"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-6", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-lg font-semibold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-xs font-medium text-muted-foreground", className),
		...props
	});
}
var Select = Select$1;
var SelectValue = SelectValue$1;
function SelectTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
		className: cn("flex h-10 w-full items-center justify-between gap-2 rounded-md border border-input bg-card px-3 text-sm outline-none transition-[border-color,box-shadow] duration-150", "focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30", "disabled:cursor-not-allowed disabled:opacity-50", "data-placeholder:text-muted-foreground", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted-foreground" })
		})]
	});
}
function SelectContent({ className, children, position = "popper", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent$1, {
		position,
		className: cn("relative z-50 max-h-72 min-w-32 overflow-hidden rounded-lg border border-border bg-popover text-popover-foreground shadow-ledger", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: "p-1",
			children
		})
	}) });
}
function SelectItem({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
		className: cn("relative flex w-full cursor-pointer items-center rounded-sm py-2 pr-8 pl-2 text-sm outline-none select-none", "focus:bg-accent focus:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, {
			className: "absolute right-2 inline-flex",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
		})]
	});
}
var Sheet = Dialog$1;
var SheetPortal = DialogPortal$1;
function SheetOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-foreground/30 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function SheetContent({ className, children, side = "right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed z-50 flex flex-col bg-card text-card-foreground shadow-ledger", "data-[state=open]:animate-in data-[state=closed]:animate-out", side === "right" && "inset-y-0 right-0 h-full w-full max-w-md border-l border-border data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right", side === "bottom" && "inset-x-0 bottom-0 max-h-[85vh] rounded-t-xl border-t border-border data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-sm p-1 text-muted-foreground hover:bg-accent hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "关闭"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("border-b border-border px-5 py-4 pr-12", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-lg font-semibold", className),
		...props
	});
}
function SheetDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("min-h-20 w-full rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground outline-none transition-[border-color,box-shadow] duration-150", "placeholder:text-muted-foreground", "focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function parseNonNeg(raw) {
	if (raw === "") return 0;
	const n = Number.parseInt(raw, 10);
	return Number.isFinite(n) && n >= 0 ? n : 0;
}
function QtyFields({ id, cartons, sets, onCartons, onSets }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: `${id}-cartons`,
				children: "件数"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: `${id}-cartons`,
					type: "number",
					min: 0,
					inputMode: "numeric",
					value: cartons,
					onChange: (e) => onCartons(parseNonNeg(e.target.value)),
					className: "pr-8 tabular-nums"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-xs text-muted-foreground",
					children: "件"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: `${id}-sets`,
				children: "套数"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: `${id}-sets`,
					type: "number",
					min: 0,
					inputMode: "numeric",
					value: sets,
					onChange: (e) => onSets(parseNonNeg(e.target.value)),
					className: "pr-8 tabular-nums"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-xs text-muted-foreground",
					children: "套"
				})]
			})]
		})]
	});
}
function formatQty(cartons, sets) {
	if (cartons === 0 && sets === 0) return "0";
	const parts = [];
	if (cartons !== 0) parts.push(`${cartons}件`);
	if (sets !== 0) parts.push(`${sets}套`);
	return parts.join("+");
}
function formatPacking(qty, unit) {
	return `${qty}${unit}/件`;
}
function todayISO(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function formatLedgerDate(iso) {
	const [y, m, d] = iso.split("-");
	if (!y || !m || !d) return iso;
	return `${Number(y)}. ${Number(m)}. ${Number(d)}`;
}
var SWATCH_RULES = [
	{
		match: /黄/,
		token: "swatch-yellow"
	},
	{
		match: /红|朱红|玫红/,
		token: "swatch-red"
	},
	{
		match: /橙/,
		token: "swatch-orange"
	},
	{
		match: /绿|青/,
		token: "swatch-green"
	},
	{
		match: /蓝|靛/,
		token: "swatch-blue"
	},
	{
		match: /粉|桃/,
		token: "swatch-pink"
	},
	{
		match: /紫|lilac/i,
		token: "swatch-violet"
	},
	{
		match: /白|米|象牙/,
		token: "swatch-white"
	},
	{
		match: /黑|墨/,
		token: "swatch-black"
	},
	{
		match: /棕|咖|褐/,
		token: "swatch-brown"
	},
	{
		match: /灰|银/,
		token: "swatch-gray"
	},
	{
		match: /金/,
		token: "swatch-gold"
	}
];
function colorSwatchToken(color) {
	return SWATCH_RULES.find((rule) => rule.match.test(color))?.token ?? "swatch-unknown";
}
function isOutOfStock(cartons, sets) {
	return cartons === 0 && sets === 0;
}
var KIND_LABEL = {
	in: "入库",
	out: "出库",
	adjust: "修正"
};
var SWATCH_BG = {
	"swatch-yellow": "bg-swatch-yellow",
	"swatch-red": "bg-swatch-red",
	"swatch-orange": "bg-swatch-orange",
	"swatch-green": "bg-swatch-green",
	"swatch-blue": "bg-swatch-blue",
	"swatch-pink": "bg-swatch-pink",
	"swatch-violet": "bg-swatch-violet",
	"swatch-white": "bg-swatch-white border border-rule",
	"swatch-black": "bg-swatch-black",
	"swatch-brown": "bg-swatch-brown",
	"swatch-gray": "bg-swatch-gray",
	"swatch-gold": "bg-swatch-gold",
	"swatch-unknown": "bg-swatch-unknown"
};
function ColorDot({ color, className }) {
	const token = colorSwatchToken(color);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": true,
		className: cn("inline-block size-2.5 shrink-0 rounded-full", SWATCH_BG[token] ?? "bg-swatch-unknown", className)
	});
}
function errorMessage(err, fallback = "操作失败") {
	if (err instanceof Error && err.message) return err.message;
	if (typeof err === "string" && err) return err;
	if (err && typeof err === "object" && "message" in err) {
		const msg = err.message;
		if (typeof msg === "string" && msg) return msg;
	}
	return fallback;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var dateInput = object({
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	q: string().optional()
});
var listInventory = createServerFn({ method: "POST" }).validator((input) => dateInput.parse(input)).handler(createSsrRpc("b4d57d43658cf0656ea7f7a2c3a742ce03669863383ec2731e7d801e29c2eb53"));
var listCategories = createServerFn({ method: "GET" }).handler(createSsrRpc("c583db61e6832c9f2ab9234aa3564e88eb66fbaf0b1245e29699488f11a410b8"));
var createCategoryInput = object({ name: string().trim().min(1).max(40) });
var createCategory = createServerFn({ method: "POST" }).validator((input) => createCategoryInput.parse(input)).handler(createSsrRpc("de4a1711697083440ea3c717fe4a09096eda99fd6efb65eb1e931b1364262a9c"));
var deleteCategoryInput = object({ id: number().int() });
var deleteCategory = createServerFn({ method: "POST" }).validator((input) => deleteCategoryInput.parse(input)).handler(createSsrRpc("0451513c68df54a1613deacffce8f664711fd087c4afc67296b054cc5e1cf617"));
var createProductInput = object({
	categoryId: number().int(),
	sku: string().trim().min(1).max(80),
	packingQty: number().int().positive(),
	packingUnit: string().trim().min(1).max(8),
	color: string().trim().min(1).max(20),
	remainingCartons: number().int().min(0),
	remainingSets: number().int().min(0)
});
var createProduct = createServerFn({ method: "POST" }).validator((input) => createProductInput.parse(input)).handler(createSsrRpc("f435bfac7f7da5ba1ace11b4ffa3dc58561c24ae456aa614eb6149b17b157a8a"));
var updateProductInput = object({
	id: number().int(),
	categoryId: number().int(),
	sku: string().trim().min(1).max(80),
	packingQty: number().int().positive(),
	packingUnit: string().trim().min(1).max(8)
});
var updateProduct = createServerFn({ method: "POST" }).validator((input) => updateProductInput.parse(input)).handler(createSsrRpc("f171e30993b05043d175c240acbe9f68ea2882aa5d4049081b9f5c8cfc811f30"));
var deleteProductInput = object({ id: number().int() });
var deleteProduct = createServerFn({ method: "POST" }).validator((input) => deleteProductInput.parse(input)).handler(createSsrRpc("f4713014b6377bbc561759ec31a67463fed1eaf81b8f8d99ad6f32aaacd4e0ff"));
var createVariantInput = object({
	productId: number().int(),
	color: string().trim().min(1).max(20),
	remainingCartons: number().int().min(0),
	remainingSets: number().int().min(0)
});
var createVariant = createServerFn({ method: "POST" }).validator((input) => createVariantInput.parse(input)).handler(createSsrRpc("8dcbe2fa136c3f389a85d0bec99c96664be889213da9a98293c4fbee3a6e84b3"));
var updateVariantInput = object({
	id: number().int(),
	color: string().trim().min(1).max(20)
});
var updateVariant = createServerFn({ method: "POST" }).validator((input) => updateVariantInput.parse(input)).handler(createSsrRpc("a3e38e0f55a1c3d0d01d152716fd6372ba525cf610d269930958765b3d755a55"));
var deleteVariantInput = object({ id: number().int() });
var deleteVariant = createServerFn({ method: "POST" }).validator((input) => deleteVariantInput.parse(input)).handler(createSsrRpc("989c7d4c1d5a03e7641125e6cb4c8709b645c4a53a9a3ac5b8750c82ad52791c"));
var recordMovementInput = object({
	variantId: number().int(),
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	kind: _enum([
		"in",
		"out",
		"adjust"
	]),
	cartons: number().int().min(0),
	sets: number().int().min(0),
	note: string().trim().max(120).optional()
});
var recordMovement = createServerFn({ method: "POST" }).validator((input) => recordMovementInput.parse(input)).handler(createSsrRpc("1b75eb6ba4817beb640e55e278f52125c3dfdc5bc08770d584a1cd843f9e2748"));
var listMovementsInput = object({ variantId: number().int() });
var listMovements = createServerFn({ method: "POST" }).validator((input) => listMovementsInput.parse(input)).handler(createSsrRpc("05710ed64c775337bb648213fa06a3d921ed64d72896e4174bc506ead86f0b4c"));
function invalidateInventory(qc) {
	qc.invalidateQueries({ queryKey: ["inventory"] });
	qc.invalidateQueries({ queryKey: ["categories"] });
	qc.invalidateQueries({ queryKey: ["movements"] });
}
function ProductFormDialog({ state, onOpenChange, categories }) {
	const qc = useQueryClient();
	const editing = state.open && state.mode === "edit" ? state.product : null;
	const [sku, setSku] = (0, import_react.useState)("");
	const [categoryId, setCategoryId] = (0, import_react.useState)("");
	const [packingQty, setPackingQty] = (0, import_react.useState)(72);
	const [packingUnit, setPackingUnit] = (0, import_react.useState)("个");
	const [color, setColor] = (0, import_react.useState)("");
	const [cartons, setCartons] = (0, import_react.useState)(0);
	const [sets, setSets] = (0, import_react.useState)(0);
	const [newCategory, setNewCategory] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!state.open) return;
		if (state.mode === "edit") {
			setSku(state.product.sku);
			setCategoryId(String(state.product.categoryId));
			setPackingQty(state.product.packingQty);
			setPackingUnit(state.product.packingUnit);
		} else {
			setSku("");
			setCategoryId(categories[0] ? String(categories[0].id) : "");
			setPackingQty(72);
			setPackingUnit("个");
			setColor("");
			setCartons(0);
			setSets(0);
		}
		setNewCategory("");
	}, [state, categories]);
	const save = useMutation({
		mutationFn: async () => {
			let catId = Number(categoryId);
			if (newCategory.trim()) catId = (await createCategory({ data: { name: newCategory.trim() } })).id;
			if (!catId) throw new Error("请选择分类");
			if (!sku.trim()) throw new Error("请填写货号");
			if (editing) {
				await updateProduct({ data: {
					id: editing.id,
					categoryId: catId,
					sku: sku.trim(),
					packingQty,
					packingUnit: packingUnit.trim() || "个"
				} });
				return;
			}
			if (!color.trim()) throw new Error("请填写颜色");
			await createProduct({ data: {
				categoryId: catId,
				sku: sku.trim(),
				packingQty,
				packingUnit: packingUnit.trim() || "个",
				color: color.trim(),
				remainingCartons: cartons,
				remainingSets: sets
			} });
		},
		onSuccess: () => {
			toast.success(editing ? "货号已更新" : "已新增货品");
			invalidateInventory(qc);
			onOpenChange(false);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: state.open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing ? "编辑货号" : "新增货品" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: editing ? "修改货号、分类与装箱规格，颜色库存请在各行单独调整。" : "先建货号，并录入第一种颜色的库存。" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "sku",
						children: "货号"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "sku",
						value: sku,
						onChange: (e) => setSku(e.target.value),
						placeholder: "H1405-83雅礼花罐"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "分类" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: categoryId,
							onValueChange: setCategoryId,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "选择分类" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(c.id),
								children: c.name
							}, c.id)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: newCategory,
							onChange: (e) => setNewCategory(e.target.value),
							placeholder: "或输入新分类名称"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "packing-qty",
							children: "装箱数量"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "packing-qty",
							type: "number",
							min: 1,
							className: "tabular-nums",
							value: packingQty,
							onChange: (e) => setPackingQty(Math.max(1, Number.parseInt(e.target.value, 10) || 1))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "packing-unit",
							children: "单位"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "packing-unit",
							value: packingUnit,
							onChange: (e) => setPackingUnit(e.target.value)
						})]
					})]
				}),
				!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "color",
						children: "颜色及型号"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "color",
						value: color,
						onChange: (e) => setColor(e.target.value),
						placeholder: "红色"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyFields, {
					id: "new-stock",
					cartons,
					sets,
					onCartons: setCartons,
					onSets: setSets
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => onOpenChange(false),
					children: "取消"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: save.isPending,
					children: save.isPending ? "保存中…" : "保存"
				})] })
			]
		})] })
	});
}
function VariantFormDialog({ state, onOpenChange }) {
	const qc = useQueryClient();
	const editing = state.open && state.mode === "edit" ? state.variant : null;
	const product = state.open ? state.product : null;
	const [color, setColor] = (0, import_react.useState)("");
	const [cartons, setCartons] = (0, import_react.useState)(0);
	const [sets, setSets] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!state.open) return;
		if (state.mode === "edit") setColor(state.variant.color);
		else {
			setColor("");
			setCartons(0);
			setSets(0);
		}
	}, [state]);
	const save = useMutation({
		mutationFn: async () => {
			if (!product) return;
			if (!color.trim()) throw new Error("请填写颜色");
			if (editing) {
				await updateVariant({ data: {
					id: editing.id,
					color: color.trim()
				} });
				return;
			}
			await createVariant({ data: {
				productId: product.id,
				color: color.trim(),
				remainingCartons: cartons,
				remainingSets: sets
			} });
		},
		onSuccess: () => {
			toast.success(editing ? "颜色已更新" : "已添加颜色");
			invalidateInventory(qc);
			onOpenChange(false);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: state.open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing ? "编辑颜色" : "添加颜色" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: product ? `${product.sku} · ${formatPacking(product.packingQty, product.packingUnit)}` : "" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "variant-color",
						children: "颜色及型号"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "variant-color",
						value: color,
						onChange: (e) => setColor(e.target.value),
						placeholder: "橙色"
					})]
				}),
				!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyFields, {
					id: "variant-stock",
					cartons,
					sets,
					onCartons: setCartons,
					onSets: setSets
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => onOpenChange(false),
					children: "取消"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: save.isPending,
					children: save.isPending ? "保存中…" : "保存"
				})] })
			]
		})] })
	});
}
function MovementFormDialog({ state, date, onOpenChange }) {
	const qc = useQueryClient();
	const [cartons, setCartons] = (0, import_react.useState)(0);
	const [sets, setSets] = (0, import_react.useState)(0);
	const [note, setNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!state.open) return;
		if (state.kind === "adjust") {
			setCartons(state.variant.remainingCartons);
			setSets(state.variant.remainingSets);
		} else {
			setCartons(0);
			setSets(0);
		}
		setNote("");
	}, [state]);
	const save = useMutation({
		mutationFn: async () => {
			if (!state.open) return;
			await recordMovement({ data: {
				variantId: state.variant.id,
				date,
				kind: state.kind,
				cartons,
				sets,
				note: note.trim() || void 0
			} });
		},
		onSuccess: () => {
			if (!state.open) return;
			toast.success(`${KIND_LABEL[state.kind]}已登记`);
			invalidateInventory(qc);
			onOpenChange(false);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const kind = state.open ? state.kind : "in";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: state.open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: {
			in: "登记入库",
			out: "登记出库",
			adjust: "修正库存"
		}[kind] }), state.open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
			state.product.sku,
			" · ",
			state.variant.color,
			" · 现有",
			" ",
			formatQty(state.variant.remainingCartons, state.variant.remainingSets)
		] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyFields, {
					id: "move",
					cartons,
					sets,
					onCartons: setCartons,
					onSets: setSets
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "move-note",
						children: "备注"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "move-note",
						value: note,
						onChange: (e) => setNote(e.target.value),
						placeholder: "可选",
						rows: 2
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => onOpenChange(false),
					children: "取消"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: save.isPending,
					children: save.isPending ? "提交中…" : "确认"
				})] })
			]
		})] })
	});
}
function HistorySheet({ state, onOpenChange }) {
	const enabled = state.open;
	const variantId = state.open ? state.variant.id : 0;
	const query = useQuery({
		queryKey: ["movements", variantId],
		queryFn: () => listMovements({ data: { variantId } }),
		enabled
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: state.open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "出入库流水" }), state.open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
			state.product.sku,
			" · ",
			state.variant.color
		] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto px-5 py-4",
			children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "加载中…"
			}) : query.data && query.data.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-3",
				children: query.data.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-b border-border pb-3 last:border-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: KIND_LABEL[m.kind]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-sm",
								children: formatQty(m.cartons, m.sets)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: formatLedgerDate(m.movementDate)
						}),
						m.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: m.note
						}) : null
					]
				}, m.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "还没有流水记录。"
			})
		})] })
	});
}
function ConfirmDeleteDialog({ state, onOpenChange }) {
	const qc = useQueryClient();
	const remove = useMutation({
		mutationFn: async () => {
			if (!state.open) return;
			if (state.type === "product") await deleteProduct({ data: { id: state.product.id } });
			else await deleteVariant({ data: { id: state.variant.id } });
		},
		onSuccess: () => {
			toast.success("已删除");
			invalidateInventory(qc);
			onOpenChange(false);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const title = state.open && state.type === "product" ? `删除货号 ${state.product.sku}？` : "删除此颜色？";
	const desc = state.open && state.type === "product" ? "将同时删除该货号下全部颜色及出入库记录，此操作无法撤销。" : state.open ? `${state.product.sku} · ${state.variant.color}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: state.open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: desc })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "取消" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			onClick: () => remove.mutate(),
			disabled: remove.isPending,
			children: "删除"
		})] })] })
	});
}
function CategoryDialog({ open, onOpenChange, categories }) {
	const qc = useQueryClient();
	const [name, setName] = (0, import_react.useState)("");
	const add = useMutation({
		mutationFn: async () => {
			if (!name.trim()) throw new Error("请填写分类名称");
			await createCategory({ data: { name: name.trim() } });
		},
		onSuccess: () => {
			toast.success("已新增分类");
			setName("");
			invalidateInventory(qc);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const remove = useMutation({
		mutationFn: (id) => deleteCategory({ data: { id } }),
		onSuccess: () => {
			toast.success("已删除分类");
			invalidateInventory(qc);
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "分类管理" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "分类用于台账分组，例如纸罐&铁罐。" })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					add.mutate();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "新分类名称"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: add.isPending,
					children: "添加"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-1",
				children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-md px-2 py-2 hover:bg-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: c.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						className: "text-primary",
						onClick: () => remove.mutate(c.id),
						children: "删除"
					})]
				}, c.id))
			})
		] })
	});
}
function ColorLabel({ color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, { color }), color]
	});
}
var DropdownMenu = Root2$1;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
		sideOffset,
		className: cn("z-50 min-w-40 overflow-hidden rounded-lg border border-border bg-popover p-1 text-popover-foreground shadow-ledger", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props
	}) });
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-sm px-2 py-2 text-sm outline-none select-none", "focus:bg-accent focus:text-accent-foreground", "data-disabled:pointer-events-none data-disabled:opacity-50", inset && "pl-8", variant === "destructive" && "text-primary focus:bg-primary/8 focus:text-primary", className),
		...props
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
function QtyCell({ cartons, sets, empty }) {
	const zero = cartons === 0 && sets === 0;
	if (empty && zero) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "—"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular-nums", zero && "text-primary"),
		children: formatQty(cartons, sets)
	});
}
function RowMenu({ product, variant, handlers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": "操作",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onMove("in", product, variant),
				children: "入库"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onMove("out", product, variant),
				children: "出库"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onMove("adjust", product, variant),
				children: "修正库存"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onHistory(product, variant),
				children: "流水"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onAddVariant(product),
				children: "添加颜色"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onEditVariant(product, variant),
				children: "编辑颜色"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => handlers.onEditProduct(product),
				children: "编辑货号"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				variant: "destructive",
				onSelect: () => handlers.onDeleteVariant(product, variant),
				children: "删除颜色"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				variant: "destructive",
				onSelect: () => handlers.onDeleteProduct(product),
				children: "删除货号"
			})
		]
	})] });
}
function LedgerTable({ categories, handlers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-xl border border-border bg-card shadow-ledger",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[720px] border-collapse text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-border bg-muted/60 text-left text-xs font-medium tracking-wide text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "货号"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "装箱数量"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "颜色及型号"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "本日入"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "本日出"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: "剩余数量"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "w-12 px-2 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "操作"
						})
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBlock, {
				category,
				handlers
			}, category.id)) })]
		})
	});
}
function CategoryBlock({ category, handlers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		colSpan: 7,
		className: "bg-primary/8 px-4 py-2 font-display text-sm font-semibold text-primary",
		children: category.name
	}) }), category.products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		colSpan: 7,
		className: "px-4 py-4 text-sm text-muted-foreground",
		children: "该分类暂无货品"
	}) }) : category.products.map((product) => product.variants.map((variant, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-rule/80 hover:bg-muted/40",
		children: [
			index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				rowSpan: product.variants.length,
				className: "border-r border-rule/70 px-4 py-3 align-top font-medium",
				children: product.sku
			}) : null,
			index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				rowSpan: product.variants.length,
				className: "border-r border-rule/70 px-3 py-3 align-top tabular-nums text-muted-foreground",
				children: formatPacking(product.packingQty, product.packingUnit)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorLabel, { color: variant.color })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyCell, {
					cartons: variant.inCartons,
					sets: variant.inSets,
					empty: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyCell, {
					cartons: variant.outCartons,
					sets: variant.outSets,
					empty: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 font-medium",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyCell, {
					cartons: variant.remainingCartons,
					sets: variant.remainingSets
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-2 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowMenu, {
					product,
					variant,
					handlers
				})
			})
		]
	}, variant.id)))] });
}
function LedgerCards({ categories, handlers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-5",
		children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "px-1 font-display text-sm font-semibold text-primary",
				children: category.name
			}), category.products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-sm text-muted-foreground",
				children: "该分类暂无货品"
			}) : category.products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-card p-3 shadow-ledger",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-2 flex items-baseline justify-between gap-3 border-b border-border pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: product.sku
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tabular-nums text-muted-foreground",
						children: formatPacking(product.packingQty, product.packingUnit)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col",
					children: product.variants.map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 border-b border-rule/60 py-2.5 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorLabel, { color: variant.color }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									"入 ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyCell, {
										cartons: variant.inCartons,
										sets: variant.inSets,
										empty: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mx-1.5",
										children: "·"
									}),
									"出 ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyCell, {
										cartons: variant.outCartons,
										sets: variant.outSets,
										empty: true
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mr-1 text-sm font-medium tabular-nums", isOutOfStock(variant.remainingCartons, variant.remainingSets) && "text-primary"),
								children: formatQty(variant.remainingCartons, variant.remainingSets)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowMenu, {
								product,
								variant,
								handlers
							})]
						})]
					}, variant.id))
				})]
			}, product.id))]
		}, category.id))
	});
}
function useDebounced(value, delay) {
	const [debounced, setDebounced] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const t = window.setTimeout(() => setDebounced(value), delay);
		return () => window.clearTimeout(t);
	}, [value, delay]);
	return debounced;
}
function InventoryApp() {
	const [date, setDate] = (0, import_react.useState)(todayISO);
	const [search, setSearch] = (0, import_react.useState)("");
	const q = useDebounced(search, 200);
	const [productDialog, setProductDialog] = (0, import_react.useState)({ open: false });
	const [variantDialog, setVariantDialog] = (0, import_react.useState)({ open: false });
	const [movementDialog, setMovementDialog] = (0, import_react.useState)({ open: false });
	const [history, setHistory] = (0, import_react.useState)({ open: false });
	const [confirm, setConfirm] = (0, import_react.useState)({ open: false });
	const [categoryOpen, setCategoryOpen] = (0, import_react.useState)(false);
	const inventoryQuery = useQuery({
		queryKey: [
			"inventory",
			date,
			q
		],
		queryFn: () => listInventory({ data: {
			date,
			q
		} })
	});
	const categoriesQuery = useQuery({
		queryKey: ["categories"],
		queryFn: () => listCategories()
	});
	const data = inventoryQuery.data;
	const categories = categoriesQuery.data ?? [];
	const handlers = (0, import_react.useMemo)(() => ({
		onAddVariant: (product) => setVariantDialog({
			open: true,
			mode: "create",
			product
		}),
		onEditProduct: (product) => setProductDialog({
			open: true,
			mode: "edit",
			product
		}),
		onDeleteProduct: (product) => setConfirm({
			open: true,
			type: "product",
			product
		}),
		onEditVariant: (product, variant) => setVariantDialog({
			open: true,
			mode: "edit",
			product,
			variant
		}),
		onDeleteVariant: (product, variant) => setConfirm({
			open: true,
			type: "variant",
			product,
			variant
		}),
		onMove: (kind, product, variant) => setMovementDialog({
			open: true,
			kind,
			product,
			variant
		}),
		onHistory: (product, variant) => setHistory({
			open: true,
			product,
			variant
		})
	}), []);
	const empty = data && data.categories.every((c) => c.products.length === 0) && data.categories.length >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-6xl flex-col gap-5 px-4 py-6 sm:px-6 sm:py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warehouse, {
									className: "size-5",
									strokeWidth: 1.75
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-[0.16em] text-muted-foreground",
									children: "WAREHOUSE LEDGER"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "font-display text-2xl font-semibold tracking-tight sm:text-3xl",
									children: "芳村仓库存"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: [
										data?.warehouseName ?? "芳村仓",
										" · ",
										formatLedgerDate(date)
									]
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: date,
									onChange: (e) => setDate(e.target.value || todayISO()),
									className: "w-[11.5rem] tabular-nums",
									"aria-label": "台账日期"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => setCategoryOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderTree, { className: "size-4" }), "分类"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setProductDialog({
										open: true,
										mode: "create"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "新增货品"]
								})
							]
						})]
					}),
					data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "货号",
								value: String(data.stats.productCount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "颜色款",
								value: String(data.stats.variantCount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "缺货",
								value: String(data.stats.outOfStock),
								warn: data.stats.outOfStock > 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "本日出入",
								value: `${data.stats.todayInLines}/${data.stats.todayOutLines}`
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 rounded-lg" }, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: "搜索货号或颜色",
							className: "pl-9",
							"aria-label": "搜索"
						})]
					}),
					inventoryQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80 rounded-xl" }) : inventoryQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border bg-card px-5 py-10 text-center text-sm text-muted-foreground",
						children: "台账加载失败，请刷新重试。"
					}) : data && !empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerTable, {
							categories: data.categories,
							handlers
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerCards, {
							categories: data.categories,
							handlers
						})
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-dashed border-border bg-card px-5 py-16 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg font-semibold",
								children: "暂无匹配货品"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: q ? "换个关键词试试，或清空搜索。" : "从新增货品开始建立台账。"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-4",
								onClick: () => setProductDialog({
									open: true,
									mode: "create"
								}),
								children: "新增货品"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductFormDialog, {
				state: productDialog,
				categories,
				onOpenChange: (open) => {
					if (!open) setProductDialog({ open: false });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantFormDialog, {
				state: variantDialog,
				onOpenChange: (open) => {
					if (!open) setVariantDialog({ open: false });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovementFormDialog, {
				state: movementDialog,
				date,
				onOpenChange: (open) => {
					if (!open) setMovementDialog({ open: false });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistorySheet, {
				state: history,
				onOpenChange: (open) => {
					if (!open) setHistory({ open: false });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDeleteDialog, {
				state: confirm,
				onOpenChange: (open) => {
					if (!open) setConfirm({ open: false });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryDialog, {
				open: categoryOpen,
				onOpenChange: setCategoryOpen,
				categories
			})
		]
	});
}
function Stat({ label, value, warn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 font-display text-xl font-semibold tabular-nums ${warn ? "text-primary" : ""}`,
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryApp, {});
}
//#endregion
export { Home as component };
