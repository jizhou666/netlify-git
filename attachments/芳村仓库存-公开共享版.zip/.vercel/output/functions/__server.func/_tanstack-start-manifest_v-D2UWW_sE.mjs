//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D2UWW_sE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-HgcPG98x.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-HgcPG98x.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dxr85TPm.js"]
	}
} });
//#endregion
export { tsrStartManifest };
